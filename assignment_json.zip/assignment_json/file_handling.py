import json


file=open(r"C:\\Users\\Suganthi Priya\\Documents\\GitHub\\assignment-mahesh\\assignment_1\\assignment6\\assignment_json\\employee.json")
data=json.load(file)
print(data)
print(type(data))

